% subplot(3,1,1)
% plot(T,cases(1,:));
% subplot(3,1,2)
% plot(T,maybe(1,:));
% subplot(3,1,3)
% plot(T,dead(1,:));
plot(T,cases(1,:)-dead(1,:))
% plot(T,cases(1,:));
% title('cases');
% figure;
% plot(T(1:N-1),dcases(1,:));
% title('dcases');
