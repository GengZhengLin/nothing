function draw_result(T,Y)
plot(T,Y);
legend('s','e','i1','i2','I1','I2','O','D');
end